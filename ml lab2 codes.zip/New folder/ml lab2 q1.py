import math

def eucilidean_distance(vec1,vec2):
    if len(vec1) != len(vec2):
       raise ValueError("vectors must have same dimension")
    sum_of_squares=0.0
    for i in range(len(vec1)):
       sum_of_squares+=(vec1[i]-vec2[i])**2
    return math.sqrt(sum_of_squares)

def manhattan_distance(vec1,vec2):
    if len(vec1) != len(vec2):
       raise ValueError("vectors must have same dimension")
    
    distance=0.0
    for i in range(len(vec1)):
       distance += abs(vec1[i]-vec2[i])
    return distance

vector1=[3, 5, 2]
vector2=[1, 7, 4]

print("Eucilidean Distance :",eucilidean_distance(vector1,vector2))
print("Manhattan Distance :",manhattan_distance(vector1,vector2))