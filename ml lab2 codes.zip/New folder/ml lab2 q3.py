def label_encoding(cateogries):
    unique_cateogries=set(cateogries)
    label_map={}

    for i, cateogries in enumerate(unique_cateogries):
        label_map[cateogries]=i

    return label_map
cateogries=['apple','banana','apple','orange','banana','apple']
label_map=label_encoding(cateogries)
print("label encoding:",label_map)